# Warehouse Inventory App

CS 360 Project Three

This app helps warehouse workers keep track of inventory. Users can create an account, log in, and add, edit, or remove items. The app saves information using SQLite. It can also send a text alert when an item reaches zero, if SMS is enabled and permitted.

To run the project, open the `Corey_Ralls_CS_360` folder in Android Studio. Wait for Gradle to sync, then run the `app` on an emulator.

Before submitting, test login, inventory changes, saved items, and SMS permissions. Actual SMS delivery needs a supported emulator or device.