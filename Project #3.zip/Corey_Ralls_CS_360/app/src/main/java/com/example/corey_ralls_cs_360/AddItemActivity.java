package com.example.corey_ralls_cs_360;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Shared add/edit form, storing real values in the SQLite database. */
public class AddItemActivity extends AppCompatActivity {
    public static final String EXTRA_ITEM_ID = "item_id";
    private InventoryDatabase database;
    private EditText nameField;
    private EditText quantityField;
    private EditText minimumField;
    private long editingId;
    private int previousQuantity = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        database = new InventoryDatabase(this);
        nameField = findViewById(R.id.itemNameText);
        quantityField = findViewById(R.id.quantityText);
        minimumField = findViewById(R.id.minimumQuantityText);
        editingId = getIntent().getLongExtra(EXTRA_ITEM_ID, -1);

        Button saveButton = findViewById(R.id.saveItemButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        if (editingId != -1) {
            InventoryDatabase.Item item = database.getItem(editingId);
            if (item == null) {
                finish();
                return;
            }
            ((TextView) findViewById(R.id.addItemTitle)).setText("Edit Inventory Item");
            saveButton.setText("Save Changes");
            nameField.setText(item.name);
            quantityField.setText(String.valueOf(item.quantity));
            minimumField.setText(String.valueOf(item.minimumQuantity));
            previousQuantity = item.quantity;
        }
        saveButton.setOnClickListener(v -> save());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void save() {
        String name = nameField.getText().toString().trim();
        String rawQuantity = quantityField.getText().toString().trim();
        String rawMinimum = minimumField.getText().toString().trim();
        if (name.isEmpty()) {
            nameField.setError("Enter an item name");
            return;
        }
        if (name.length() > 100) {
            nameField.setError("Item names must be 100 characters or less");
            return;
        }
        int quantity;
        int minimum;
        try {
            quantity = Integer.parseInt(rawQuantity);
            minimum = rawMinimum.isEmpty() ? 0 : Integer.parseInt(rawMinimum);
            if (quantity < 0 || minimum < 0) throw new NumberFormatException();
        } catch (NumberFormatException error) {
            quantityField.setError("Enter valid non-negative whole numbers");
            return;
        }
        boolean success = editingId == -1
                ? database.addItem(name, quantity, minimum)
                : database.updateItem(editingId, name, quantity, minimum);
        if (!success) {
            Toast.makeText(this, "Save failed. Item names must be unique.", Toast.LENGTH_LONG).show();
            return;
        }
        // Text alerts are attempted only after the database saves the new quantity.
        LowStockNotifier.sendIfZero(this, name, previousQuantity, quantity);
        Toast.makeText(this, "Inventory saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
