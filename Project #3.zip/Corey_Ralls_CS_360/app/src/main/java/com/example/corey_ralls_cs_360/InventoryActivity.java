package com.example.corey_ralls_cs_360;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/** Displays persistent inventory as a grid with working CRUD controls. */
public class InventoryActivity extends AppCompatActivity {
    private InventoryDatabase database;
    private TableLayout table;
    private TextView emptyMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        database = new InventoryDatabase(this);
        table = findViewById(R.id.inventoryTable);
        emptyMessage = findViewById(R.id.emptyInventoryText);
        findViewById(R.id.addItemButton).setOnClickListener(v ->
                startActivity(new Intent(this, AddItemActivity.class)));
        findViewById(R.id.notificationsButton).setOnClickListener(v ->
                startActivity(new Intent(this, NotificationsActivity.class)));
        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGrid();
    }

    private void refreshGrid() {
        table.removeAllViews();
        List<InventoryDatabase.Item> items = database.getAllItems();
        emptyMessage.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        if (items.isEmpty()) return;
        TableRow heading = new TableRow(this);
        heading.setPadding(2, dp(7), 2, dp(7));
        heading.addView(label("Item", true));
        heading.addView(label("Qty", true));
        heading.addView(label("Actions", true));
        table.addView(heading);

        for (InventoryDatabase.Item item : items) {
            TableRow row = new TableRow(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(2, dp(8), 2, dp(8));
            TextView name = label(item.name, false);
            name.setMaxWidth(dp(120));
            row.addView(name);

            LinearLayout countColumn = new LinearLayout(this);
            countColumn.setGravity(Gravity.CENTER);
            countColumn.setOrientation(LinearLayout.VERTICAL);
            TextView quantity = label(String.valueOf(item.quantity), true);
            if (item.quantity == 0) quantity.setTextColor(0xFFC62828);
            quantity.setGravity(Gravity.CENTER);
            countColumn.addView(quantity);
            LinearLayout adjust = new LinearLayout(this);
            adjust.setOrientation(LinearLayout.HORIZONTAL);
            Button minus = actionButton("−");
            Button plus = actionButton("+");
            minus.setContentDescription("Decrease " + item.name);
            plus.setContentDescription("Increase " + item.name);
            minus.setEnabled(item.quantity > 0);
            minus.setOnClickListener(v -> changeQuantity(item, -1));
            plus.setOnClickListener(v -> changeQuantity(item, 1));
            adjust.addView(minus);
            adjust.addView(plus);
            countColumn.addView(adjust);
            row.addView(countColumn);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.VERTICAL);
            Button edit = actionButton("Edit");
            Button delete = actionButton("Delete");
            edit.setOnClickListener(v -> {
                Intent intent = new Intent(this, AddItemActivity.class);
                intent.putExtra(AddItemActivity.EXTRA_ITEM_ID, item.id);
                startActivity(intent);
            });
            delete.setOnClickListener(v -> confirmDeletion(item));
            actions.addView(edit);
            actions.addView(delete);
            row.addView(actions);
            table.addView(row);
            View divider = new View(this);
            divider.setBackgroundColor(0xFFDDDDDD);
            table.addView(divider, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT, dp(1)));
        }
    }

    private TextView label(String value, boolean strong) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextSize(15);
        label.setPadding(dp(3), dp(6), dp(3), dp(6));
        if (strong) label.setTypeface(null, android.graphics.Typeface.BOLD);
        return label;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinimumHeight(dp(40));
        button.setPadding(dp(5), 0, dp(5), 0);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void changeQuantity(InventoryDatabase.Item item, int amount) {
        Integer next = database.adjustQuantity(item.id, amount);
        if (next == null) {
            Toast.makeText(this, "Unable to change quantity", Toast.LENGTH_SHORT).show();
            return;
        }
        LowStockNotifier.sendIfZero(this, item.name, item.quantity, next);
        refreshGrid();
    }

    private void confirmDeletion(InventoryDatabase.Item item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete " + item.name + "?")
                .setMessage("This will remove the item from the saved inventory.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (database.deleteItem(item.id)) refreshGrid();
                    else Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                }).show();
    }

    @Override
    protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
