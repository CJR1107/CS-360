package com.example.corey_ralls_cs_360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores warehouse inventory and independently stored local login accounts. */
public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "warehouse_inventory.db";
    private static final int DB_VERSION = 1;
    private static final int HASH_ITERATIONS = 120000;
    private static final int HASH_BITS = 256;

    public InventoryDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                "salt BLOB NOT NULL, password_hash BLOB NOT NULL)");
        db.execSQL("CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL COLLATE NOCASE UNIQUE, " +
                "quantity INTEGER NOT NULL CHECK (quantity >= 0), " +
                "minimum_quantity INTEGER NOT NULL DEFAULT 0 CHECK (minimum_quantity >= 0))");
        // Intentionally no sample rows: users populate the database themselves.
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No destructive migration: version 1 is the initial class-project schema.
    }

    /** Passwords are salted and hashed; plaintext passwords are never stored. */
    public boolean register(String username, String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] hash = hashPassword(password, salt);
        if (hash == null) return false;
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("salt", salt);
        values.put("password_hash", hash);
        return getWritableDatabase().insert("users", null, values) != -1;
    }

    public boolean authenticate(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                "users", new String[]{"salt", "password_hash"},
                "username = ? COLLATE NOCASE", new String[]{username.trim()},
                null, null, null)) {
            if (!cursor.moveToFirst()) return false;
            byte[] actualHash = cursor.getBlob(1);
            byte[] inputHash = hashPassword(password, cursor.getBlob(0));
            return inputHash != null && java.security.MessageDigest.isEqual(actualHash, inputHash);
        }
    }

    private byte[] hashPassword(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, HASH_ITERATIONS, HASH_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (Exception error) {
            return null;
        } finally {
            spec.clearPassword();
        }
    }

    public static class Item {
        public final long id;
        public final String name;
        public final int quantity;
        public final int minimumQuantity;

        Item(long id, String name, int quantity, int minimumQuantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.minimumQuantity = minimumQuantity;
        }
    }

    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("items",
                new String[]{"id", "name", "quantity", "minimum_quantity"},
                null, null, null, null, "name COLLATE NOCASE ASC")) {
            while (cursor.moveToNext()) {
                items.add(new Item(cursor.getLong(0), cursor.getString(1),
                        cursor.getInt(2), cursor.getInt(3)));
            }
        }
        return items;
    }

    public Item getItem(long id) {
        try (Cursor cursor = getReadableDatabase().query("items",
                new String[]{"id", "name", "quantity", "minimum_quantity"},
                "id = ?", new String[]{Long.toString(id)}, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new Item(cursor.getLong(0), cursor.getString(1),
                    cursor.getInt(2), cursor.getInt(3));
        }
    }

    public boolean addItem(String name, int quantity, int minimumQuantity) {
        ContentValues values = itemValues(name, quantity, minimumQuantity);
        return getWritableDatabase().insert("items", null, values) != -1;
    }

    public boolean updateItem(long id, String name, int quantity, int minimumQuantity) {
        ContentValues values = itemValues(name, quantity, minimumQuantity);
        return getWritableDatabase().update("items", values, "id = ?",
                new String[]{Long.toString(id)}) == 1;
    }

    private ContentValues itemValues(String name, int quantity, int minimumQuantity) {
        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);
        values.put("minimum_quantity", minimumQuantity);
        return values;
    }

    public boolean deleteItem(long id) {
        return getWritableDatabase().delete("items", "id = ?",
                new String[]{Long.toString(id)}) == 1;
    }

    /** Returns the saved quantity or null if the change failed / was invalid. */
    public Integer adjustQuantity(long id, int amount) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Item item = getItem(id);
            if (item == null || (amount < 0 && item.quantity < -amount)) return null;
            long next = (long) item.quantity + amount;
            if (next < 0 || next > Integer.MAX_VALUE) return null;
            ContentValues values = new ContentValues();
            values.put("quantity", (int) next);
            if (db.update("items", values, "id = ?", new String[]{Long.toString(id)}) != 1) {
                return null;
            }
            db.setTransactionSuccessful();
            return (int) next;
        } finally {
            db.endTransaction();
        }
    }
}
