package com.example.corey_ralls_cs_360;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

/** Optional SMS alert; failures must never block normal inventory operations. */
public final class LowStockNotifier {
    private static final String PREFERENCES = "stock_alert_settings";
    public static final String ENABLED = "enabled";
    public static final String DESTINATION = "destination";

    private LowStockNotifier() { }

    public static SharedPreferences settings(Context context) {
        return context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    public static boolean validPhone(String input) {
        return input != null && input.matches("\\+?[0-9]{4,15}");
    }

    public static void sendIfZero(Context context, String itemName, int previous, int current) {
        // Notify for newly created zero-stock items or when an existing item reaches zero.
        if (current != 0 || previous == 0) return;
        SharedPreferences preferences = settings(context);
        if (!preferences.getBoolean(ENABLED, false)) return;
        String number = preferences.getString(DESTINATION, "");
        if (!validPhone(number) || ContextCompat.checkSelfPermission(context,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return;
        try {
            SmsManager sms = context.getSystemService(SmsManager.class);
            if (sms == null) throw new IllegalStateException("SMS unavailable");
            sms.sendTextMessage(number, null,
                    "Warehouse Inventory: " + itemName + " is out of stock (quantity 0).",
                    null, null);
            Toast.makeText(context, "SMS alert requested", Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(context, "Item saved, but SMS could not be sent on this device",
                    Toast.LENGTH_LONG).show();
        }
    }
}
