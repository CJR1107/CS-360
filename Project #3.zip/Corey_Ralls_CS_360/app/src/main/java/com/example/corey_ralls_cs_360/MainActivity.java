package com.example.corey_ralls_cs_360;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Users must authenticate or register before the inventory screen opens. */
public class MainActivity extends AppCompatActivity {
    private InventoryDatabase database;
    private EditText usernameField;
    private EditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = new InventoryDatabase(this);
        usernameField = findViewById(R.id.usernameText);
        passwordField = findViewById(R.id.passwordText);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);
        loginButton.setOnClickListener(v -> submit(false));
        createAccountButton.setOnClickListener(v -> submit(true));
    }

    private void submit(boolean registering) {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();
        if (username.length() < 3 || username.length() > 30) {
            usernameField.setError("Use 3–30 characters for the username");
            return;
        }
        if (password.length() < 6) {
            passwordField.setError("Use at least 6 characters for the password");
            return;
        }

        boolean succeeded = registering
                ? database.register(username, password)
                : database.authenticate(username, password);
        if (!succeeded) {
            Toast.makeText(this, registering
                    ? "Username already exists or account could not be saved"
                    : "Incorrect username or password", Toast.LENGTH_LONG).show();
            return;
        }
        passwordField.setText("");
        startActivity(new Intent(this, InventoryActivity.class));
        finish(); // Back should not bypass login after logging out.
    }

    @Override
    protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
