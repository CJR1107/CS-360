package com.example.corey_ralls_cs_360;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/** SMS is optional; the app remains usable when permission is declined. */
public class NotificationsActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 100;
    private Switch lowInventorySwitch;
    private EditText phoneField;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        lowInventorySwitch = findViewById(R.id.lowInventorySwitch);
        phoneField = findViewById(R.id.smsPhoneText);
        status = findViewById(R.id.permissionStatusText);
        Button allowButton = findViewById(R.id.allowSmsButton);
        Button saveButton = findViewById(R.id.saveSmsButton);
        Button notNowButton = findViewById(R.id.notNowButton);

        lowInventorySwitch.setChecked(LowStockNotifier.settings(this).getBoolean(
                LowStockNotifier.ENABLED, false));
        phoneField.setText(LowStockNotifier.settings(this).getString(
                LowStockNotifier.DESTINATION, ""));
        updateStatus();

        allowButton.setOnClickListener(v -> {
            if (!hasPermission()) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                updateStatus();
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            }
        });
        saveButton.setOnClickListener(v -> savePreferences());
        notNowButton.setOnClickListener(v -> {
            LowStockNotifier.settings(this).edit()
                    .putBoolean(LowStockNotifier.ENABLED, false).apply();
            finish();
        });
    }

    private boolean hasPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void savePreferences() {
        boolean enabled = lowInventorySwitch.isChecked();
        String number = phoneField.getText().toString().trim()
                .replace(" ", "").replace("-", "").replace("(", "").replace(")", "");
        if (enabled && !LowStockNotifier.validPhone(number)) {
            phoneField.setError("Enter a phone number (digits, optional leading +)");
            return;
        }
        if (enabled && !hasPermission()) {
            Toast.makeText(this, "Grant SMS permission first, or turn alerts off",
                    Toast.LENGTH_LONG).show();
            return;
        }
        LowStockNotifier.settings(this).edit()
                .putBoolean(LowStockNotifier.ENABLED, enabled)
                .putString(LowStockNotifier.DESTINATION, number).apply();
        Toast.makeText(this, "Notification settings saved", Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void updateStatus() {
        boolean enabled = LowStockNotifier.settings(this).getBoolean(
                LowStockNotifier.ENABLED, false);
        if (!hasPermission()) {
            status.setText("SMS permission not granted. Inventory features still work.");
        } else if (enabled) {
            status.setText("SMS alerts enabled for items reaching zero.");
        } else {
            status.setText("SMS permission available. Save settings to enable alerts.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == SMS_PERMISSION_CODE) {
            if (results.length == 0 || results[0] != PackageManager.PERMISSION_GRANTED) {
                LowStockNotifier.settings(this).edit()
                        .putBoolean(LowStockNotifier.ENABLED, false).apply();
                lowInventorySwitch.setChecked(false);
            }
            updateStatus();
        }
    }
}
